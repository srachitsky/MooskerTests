package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AbstractPage {
    WebDriver driver;

    @FindBy(xpath = "//*[@id='menu-item-4164']/a")
    public WebElement ourApproach;

    @FindBy(xpath = "//*[@id='menu-item-4163']/a")
    public WebElement ourPlatform;

    @FindBy(xpath = "//*[@id='menu-item-4172']/a")
    public WebElement ourSolutions;

    @FindBy(xpath = "//*[@id='menu-item-4162']/a")
    public WebElement ourPeople;

    @FindBy(xpath = "//*[@id='menu-item-4167']/a")
    public WebElement ourJoinUs;

    @FindBy(xpath = "//*[@id='menu-item-4166']/a")
    public WebElement ourBlog;
    public PageObjects.AbstractPage AbstractPage;


    public AbstractPage() {
        this.driver = driver;
        PageFactory.initElements(this.driver, this);
    }

    public AbstractPage(WebDriver driver) {
    }

    public WebElement getLogo() {
        return driver.findElement(By.cssSelector(".icon--logo"));
    }

    public HomePage clickLogo() {
        clickLogo();
        return new HomePage(driver);
    }
    {}}
