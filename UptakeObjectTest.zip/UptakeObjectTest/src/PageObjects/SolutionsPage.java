package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;



public class SolutionsPage extends AbstractPage {

    private final AbstractPage abstractPage;
    public HomePage BasePageTest;

    @FindBy(css = "#Planing .lead")
    WebElement planingForecastingText;

    @FindBy(id = "Planing")
    WebElement planningForecastingSection;

    @FindBy(css = "#Planing .icon--illo")
    WebElement planingForecastingIcon;

    public SolutionsPage(WebDriver driver) {
        super(driver);
        abstractPage = new AbstractPage(driver) {

            HomePage BasePageTest = new HomePage(driver);


        }
        ;

    }

    public SolutionsPage(AbstractPage abstractPage) {
        super();
        this.abstractPage = abstractPage;
    }

    public boolean planningForecastingSectionisDisplayed() {

        if (planningForecastingSection.isDisplayed() &&
                planingForecastingIcon.isDisplayed() &&
                planingForecastingText.isDisplayed()) return true;
        else return false;
    }

    }



