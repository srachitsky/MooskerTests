package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


	public class PlatFormPage extends AbstractPage {

        public PlatformPage() {

        }

        {

		public PeoplePage();

            WebDriver driver {

		}

		class PlatformPage extends AbstractPage {

			public PlatformPage(WebDriver driver) {
				super(driver);
				PageFactory.initElements(driver, this);
			}


			@FindBy(xpath = "//h2[contains(.,'We built a platform that will transform the world of industry.')]/a")
			public WebElement Heading;

			@FindBy(xpath = "//a[contains(.,'Tools & Services')]/a")
			public WebElement Tools;

			@FindBy(xpath = "//a[contains(.,'Generation')]/a")
			public WebElement Generation;

			@FindBy(xpath = "//a[contains(.,'Analysis')]/a")
			public WebElement Analysis;


			public String getPageTitle() {
				String title = driver.getTitle();
				return title;
			}

			public boolean verifyBasePageTitle() {
				String expectedPageTitle = "PlatForm";
				return getPageTitle().contains(expectedPageTitle);
			}


		}
	}

	}


