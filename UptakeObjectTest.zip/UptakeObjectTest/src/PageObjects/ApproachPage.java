package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.concurrent.TimeUnit;

public class ApproachPage {


    private static WebElement element = null;
    private WebDriver driver;

    public WebDriver getDriver(){
        return driver;
    }

    public ApproachPage(WebDriver driver){
        if(driver==null)
            driver = new FirefoxDriver();
            driver.get("http://uptake.com/");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

    }

    public static WebElement Partnerships(WebDriver driver){

        element = driver.findElement(By.xpath("//h3[contains(.,'Partnerships with Industry Leaders ')]"));

        return element;

    }

    public static WebElement OnTheGround(WebDriver driver){

        element = driver.findElement(By.xpath("//h3[contains(.,'On-The-Ground Research ')]"));

        return element;

    }

    public static WebElement PlatformApproach(WebDriver driver){

        element = driver.findElement(By.xpath("//h3[contains(.,'A Platform Approach ')]"));

        return element;

    }

    public static WebElement Integration(WebDriver driver){

        element = driver.findElement(By.xpath("//h3[contains(.,'Integration into Workflow ')]"));

        return element;

    }

    public static WebElement Entrepreneurs(WebDriver driver){

        element = driver.findElement(By.xpath("//h3[contains(.,'A Multidisciplinary Team of Entrepreneurs ')]"));

        return element;

    }

    public static WebElement Heading(WebDriver driver){

        element = driver.findElement(By.xpath("//h2[contains(.,'How we build our products is just as important as what we build.')]"));

        return element;

    }

}

