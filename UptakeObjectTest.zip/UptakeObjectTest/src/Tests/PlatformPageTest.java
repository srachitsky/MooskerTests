package pageObjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;



class PlatformPage {

  private static WebElement element = null;
  private WebDriver driver;

  public WebDriver getDriver(){
    return driver;
  }

  public PlatformPage(WebDriver driver){
    if(driver==null)
      driver = new FirefoxDriver();
    driver.get("http://uptake.com/");
    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

  }

  public static WebElement Partnerships(WebDriver driver){

    element = driver.findElement(By.xpath("//*[@id='how']/div/div[1]"));

    return element;

  }

  public static WebElement OnTheGround(WebDriver driver){

    element = driver.findElement(By.xpath("//*[@id='how']/div/div[2]"));

    return element;

  }

  public static WebElement PlatformApproach(WebDriver driver){

    element = driver.findElement(By.xpath("//*[@id='how']/div/div[3]"));

    return element;

  }

  public static WebElement Integration(WebDriver driver){

    element = driver.findElement(By.xpath("//*[@id='how']/div/div[4]"));

    return element;

  }

  public static WebElement Entrepreneurs(WebDriver driver){

    element = driver.findElement(By.xpath("//*[@id='how']/div/div[5]"));

    return element;

  }

  public static WebElement OurPlatform(WebDriver driver){

    element = driver.findElement(By.xpath("html/body/div[4]/div/main/a/div/div/div"));

    return element;

  }

}

