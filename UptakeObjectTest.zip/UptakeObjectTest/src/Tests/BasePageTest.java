import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.util.concurrent.TimeUnit;

public class BasePageTest {

    public WebDriver driver = new FirefoxDriver();

    public BasePageTest() {

    }


    @BeforeMethod
    public void beforeEveryMethod() {
        driver = new FirefoxDriver();
        driver.get("http://uptake.com");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @AfterMethod
    public void afterEveryMethod() {
        driver.quit();
        driver = null;
    }

}


