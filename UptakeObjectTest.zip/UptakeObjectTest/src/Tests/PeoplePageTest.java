import PageObjects.AbstractPage;
import PageObjects.HomePage;
import PageObjects.SolutionsPage;
import junit.framework.Assert;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class SolutionsTest extends PageObjects.AbstractPage {
    SolutionsPage solutionsPage;
    HomePage homePage;

    @Test
    public void linkToHomePageTest() {
        WebDriver driver;
        driver.get("http://uptake.com/solutions");
        solutionsPage = new SolutionsPage(driver);
        homePage = solutionsPage.AbstractPage.clickLogo();
        Assert.assertTrue(homePage.getUptakeDescription().isDisplayed
    }
}