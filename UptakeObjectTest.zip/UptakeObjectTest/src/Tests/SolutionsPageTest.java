import PageObjects.BasePageTest;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class SolutionsTest extends BasePageTest {
  SolutionsPage solutionsPage;
  HomePage homePage;

  @Test
  public void linkToHomePageTest() {
    driver.get("http://uptake.com/solutions");
    solutionsPage = new SolutionsPage(driver);
    homePage = HomePage.
    Assert.assertTrue(homePage.Description().isDisplayed());
  }

  private class HomePage {
    public static org.testng.Assert Assert;


    public WebElement Description() {
    }
  }
}